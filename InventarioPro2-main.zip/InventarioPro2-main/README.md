# InventarioPro2
proyecto sistema de inventario demo
